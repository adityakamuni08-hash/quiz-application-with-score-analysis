package com.example.quizapp.repository;
import com.example.quizapp.model.QuizQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface QuizQuestionRepository extends JpaRepository<QuizQuestion, Long> {
    List<QuizQuestion> findByTopicIgnoreCase(String topic);
}
